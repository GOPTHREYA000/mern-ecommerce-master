/*
 *
 * Homepage constants
 *
 */

export const DEFAULT_ACTION = 'src/Homepage/DEFAULT_ACTION';
