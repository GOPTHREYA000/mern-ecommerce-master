/*
 *
 * Contact constants
 *
 */

export const CONTACT_FORM_CHANGE = 'src/Contact/CONTACT_FORM_CHANGE';
export const SET_CONTACT_FORM_ERRORS = 'src/Contact/SET_CONTACT_FORM_ERRORS';
export const CONTACT_FORM_RESET = 'src/Contact/CONTACT_FORM_RESET';
